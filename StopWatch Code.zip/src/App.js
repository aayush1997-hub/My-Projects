import React from "react";
import "./styles.css";
import StopWatch from "./StopWatch.js";

export default function App() {
  return (
    <div className="App">
      <StopWatch />
    </div>
  );
}
