import React from "react";
import "./styles.css";
import ParagraphCounter from "./ParagraphCounter.js";

export default function App() {
  return (
    <div className="App">
      <ParagraphCounter />
    </div>
  );
}
